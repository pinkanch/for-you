<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>for you</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="card">
        <h2 class="title">i have crush on you!</h2>
        <img src="rawrr.jpg" alt="Birthday Image" class="birthday-image">
        <p class="message">kalau kamu adalah samudra dengan segala ombak nya, aku adalah satu-satunya orang yang akan melubangi perahu ku agar aku bisa tenggelam dengan mu :)</p>
        <p></p>
        <p>Tolong jangan cari tau aku :)</p>
        <audio controls autoplay>
            <source src="musik.mp3" type="audio/mp3">
          
        </audio>
    </div>

    <!-- Animasi love di latar belakang -->
    <div class="background-love">
        <div class="love love1"></div>
        <div class="love love2"></div>
        <div class="love love3"></div>
        <div class="love love4"></div>
        <div class="love love5"></div>
    </div>
</body>
</html>
